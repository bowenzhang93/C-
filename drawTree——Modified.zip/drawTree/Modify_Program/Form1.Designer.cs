﻿namespace Modify_Program
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Generate = new System.Windows.Forms.Button();
            this.lab_angular1 = new System.Windows.Forms.Label();
            this.txt_Angular1 = new System.Windows.Forms.TextBox();
            this.lab_angular2 = new System.Windows.Forms.Label();
            this.txt_angular2 = new System.Windows.Forms.TextBox();
            this.lab_x0 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lab_y0 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lab_length = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_Generate
            // 
            this.btn_Generate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Generate.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_Generate.Location = new System.Drawing.Point(314, 452);
            this.btn_Generate.Name = "btn_Generate";
            this.btn_Generate.Size = new System.Drawing.Size(75, 23);
            this.btn_Generate.TabIndex = 0;
            this.btn_Generate.Text = "Generate";
            this.btn_Generate.UseVisualStyleBackColor = true;
            this.btn_Generate.Click += new System.EventHandler(this.btn_Generate_Click);
            // 
            // lab_angular1
            // 
            this.lab_angular1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lab_angular1.AutoSize = true;
            this.lab_angular1.Location = new System.Drawing.Point(30, 9);
            this.lab_angular1.Name = "lab_angular1";
            this.lab_angular1.Size = new System.Drawing.Size(23, 12);
            this.lab_angular1.TabIndex = 1;
            this.lab_angular1.Text = "θ1";
            // 
            // txt_Angular1
            // 
            this.txt_Angular1.Location = new System.Drawing.Point(59, 4);
            this.txt_Angular1.Name = "txt_Angular1";
            this.txt_Angular1.Size = new System.Drawing.Size(62, 21);
            this.txt_Angular1.TabIndex = 2;
            this.txt_Angular1.Text = "35";
            // 
            // lab_angular2
            // 
            this.lab_angular2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lab_angular2.AutoSize = true;
            this.lab_angular2.Location = new System.Drawing.Point(30, 36);
            this.lab_angular2.Name = "lab_angular2";
            this.lab_angular2.Size = new System.Drawing.Size(23, 12);
            this.lab_angular2.TabIndex = 1;
            this.lab_angular2.Text = "θ2";
            // 
            // txt_angular2
            // 
            this.txt_angular2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_angular2.Location = new System.Drawing.Point(59, 31);
            this.txt_angular2.Name = "txt_angular2";
            this.txt_angular2.Size = new System.Drawing.Size(62, 21);
            this.txt_angular2.TabIndex = 2;
            this.txt_angular2.Text = "25";
            // 
            // lab_x0
            // 
            this.lab_x0.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lab_x0.AutoSize = true;
            this.lab_x0.Location = new System.Drawing.Point(141, 11);
            this.lab_x0.Name = "lab_x0";
            this.lab_x0.Size = new System.Drawing.Size(29, 12);
            this.lab_x0.TabIndex = 1;
            this.lab_x0.Text = "per1";
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox1.Location = new System.Drawing.Point(170, 6);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(62, 21);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = "0.6";
            // 
            // lab_y0
            // 
            this.lab_y0.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lab_y0.AutoSize = true;
            this.lab_y0.Location = new System.Drawing.Point(141, 38);
            this.lab_y0.Name = "lab_y0";
            this.lab_y0.Size = new System.Drawing.Size(29, 12);
            this.lab_y0.TabIndex = 1;
            this.lab_y0.Text = "per2";
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox2.Location = new System.Drawing.Point(170, 33);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(62, 21);
            this.textBox2.TabIndex = 2;
            this.textBox2.Text = "0.7";
            // 
            // lab_length
            // 
            this.lab_length.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lab_length.AutoSize = true;
            this.lab_length.Location = new System.Drawing.Point(257, 11);
            this.lab_length.Name = "lab_length";
            this.lab_length.Size = new System.Drawing.Size(41, 12);
            this.lab_length.TabIndex = 1;
            this.lab_length.Text = "k(0-1)";
            // 
            // textBox3
            // 
            this.textBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox3.Location = new System.Drawing.Point(303, 6);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(62, 21);
            this.textBox3.TabIndex = 2;
            this.textBox3.Text = "0.7";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(401, 478);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.lab_y0);
            this.Controls.Add(this.txt_angular2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lab_length);
            this.Controls.Add(this.lab_angular2);
            this.Controls.Add(this.lab_x0);
            this.Controls.Add(this.txt_Angular1);
            this.Controls.Add(this.lab_angular1);
            this.Controls.Add(this.btn_Generate);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Generate;
        private System.Windows.Forms.Label lab_angular1;
        private System.Windows.Forms.TextBox txt_Angular1;
        private System.Windows.Forms.Label lab_angular2;
        private System.Windows.Forms.TextBox txt_angular2;
        private System.Windows.Forms.Label lab_x0;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lab_y0;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lab_length;
        private System.Windows.Forms.TextBox textBox3;
    }
}

