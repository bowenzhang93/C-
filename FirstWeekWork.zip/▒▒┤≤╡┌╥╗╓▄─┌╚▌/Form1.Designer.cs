﻿namespace 北大第一周内容
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Sub = new System.Windows.Forms.Button();
            this.btn_Mul = new System.Windows.Forms.Button();
            this.btn_Div = new System.Windows.Forms.Button();
            this.lab_Num1 = new System.Windows.Forms.Label();
            this.lab_Num2 = new System.Windows.Forms.Label();
            this.txt_Num1 = new System.Windows.Forms.TextBox();
            this.txt_Num2 = new System.Windows.Forms.TextBox();
            this.txt_Result = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Add
            // 
            this.btn_Add.BackColor = System.Drawing.Color.LawnGreen;
            this.btn_Add.Font = new System.Drawing.Font("Algerian", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add.Location = new System.Drawing.Point(73, 209);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(75, 32);
            this.btn_Add.TabIndex = 0;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = false;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Sub
            // 
            this.btn_Sub.BackColor = System.Drawing.Color.Cyan;
            this.btn_Sub.Font = new System.Drawing.Font("Algerian", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sub.Location = new System.Drawing.Point(181, 209);
            this.btn_Sub.Name = "btn_Sub";
            this.btn_Sub.Size = new System.Drawing.Size(75, 32);
            this.btn_Sub.TabIndex = 0;
            this.btn_Sub.Text = "Sub";
            this.btn_Sub.UseVisualStyleBackColor = false;
            this.btn_Sub.Click += new System.EventHandler(this.btn_Sub_Click);
            // 
            // btn_Mul
            // 
            this.btn_Mul.BackColor = System.Drawing.Color.DarkViolet;
            this.btn_Mul.Font = new System.Drawing.Font("Algerian", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Mul.Location = new System.Drawing.Point(284, 209);
            this.btn_Mul.Name = "btn_Mul";
            this.btn_Mul.Size = new System.Drawing.Size(75, 32);
            this.btn_Mul.TabIndex = 0;
            this.btn_Mul.Text = "Mul";
            this.btn_Mul.UseVisualStyleBackColor = false;
            this.btn_Mul.Click += new System.EventHandler(this.btn_Mul_Click);
            // 
            // btn_Div
            // 
            this.btn_Div.BackColor = System.Drawing.Color.Crimson;
            this.btn_Div.Font = new System.Drawing.Font("Algerian", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Div.Location = new System.Drawing.Point(391, 209);
            this.btn_Div.Name = "btn_Div";
            this.btn_Div.Size = new System.Drawing.Size(75, 32);
            this.btn_Div.TabIndex = 0;
            this.btn_Div.Text = "Div";
            this.btn_Div.UseVisualStyleBackColor = false;
            this.btn_Div.Click += new System.EventHandler(this.btn_Div_Click);
            // 
            // lab_Num1
            // 
            this.lab_Num1.AutoSize = true;
            this.lab_Num1.Font = new System.Drawing.Font("Kristen ITC", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Num1.Location = new System.Drawing.Point(69, 46);
            this.lab_Num1.Name = "lab_Num1";
            this.lab_Num1.Size = new System.Drawing.Size(86, 22);
            this.lab_Num1.TabIndex = 1;
            this.lab_Num1.Text = "Number 1:";
            // 
            // lab_Num2
            // 
            this.lab_Num2.AutoSize = true;
            this.lab_Num2.Font = new System.Drawing.Font("Kristen ITC", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Num2.Location = new System.Drawing.Point(69, 94);
            this.lab_Num2.Name = "lab_Num2";
            this.lab_Num2.Size = new System.Drawing.Size(87, 22);
            this.lab_Num2.TabIndex = 1;
            this.lab_Num2.Text = "Number 2:";
            // 
            // txt_Num1
            // 
            this.txt_Num1.Location = new System.Drawing.Point(161, 46);
            this.txt_Num1.Name = "txt_Num1";
            this.txt_Num1.Size = new System.Drawing.Size(171, 25);
            this.txt_Num1.TabIndex = 2;
            // 
            // txt_Num2
            // 
            this.txt_Num2.Location = new System.Drawing.Point(162, 94);
            this.txt_Num2.Name = "txt_Num2";
            this.txt_Num2.Size = new System.Drawing.Size(171, 25);
            this.txt_Num2.TabIndex = 2;
            // 
            // txt_Result
            // 
            this.txt_Result.Location = new System.Drawing.Point(162, 143);
            this.txt_Result.Name = "txt_Result";
            this.txt_Result.Size = new System.Drawing.Size(171, 25);
            this.txt_Result.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Kristen ITC", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(93, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "Result:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.Gold;
            this.btn_Refresh.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.Location = new System.Drawing.Point(349, 46);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(117, 122);
            this.btn_Refresh.TabIndex = 3;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 273);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.txt_Result);
            this.Controls.Add(this.txt_Num2);
            this.Controls.Add(this.txt_Num1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lab_Num2);
            this.Controls.Add(this.lab_Num1);
            this.Controls.Add(this.btn_Div);
            this.Controls.Add(this.btn_Mul);
            this.Controls.Add(this.btn_Sub);
            this.Controls.Add(this.btn_Add);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_Sub;
        private System.Windows.Forms.Button btn_Mul;
        private System.Windows.Forms.Button btn_Div;
        private System.Windows.Forms.Label lab_Num1;
        private System.Windows.Forms.Label lab_Num2;
        private System.Windows.Forms.TextBox txt_Num1;
        private System.Windows.Forms.TextBox txt_Num2;
        private System.Windows.Forms.TextBox txt_Result;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Refresh;
    }
}

